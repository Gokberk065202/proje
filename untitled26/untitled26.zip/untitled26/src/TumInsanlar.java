public abstract class TumInsanlar {
    public void setTcGir(){
    }
    public void setAdresGir(){
    }
    public void setDogumtGir(){
    }
    public void setCinsiyetGir(){
    }
    public void setADGir(){
    }
    public void setSoyadGir(){
    }
    public void setSifreGir(){
    }

}
